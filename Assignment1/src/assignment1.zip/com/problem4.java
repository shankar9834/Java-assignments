
/* problem statement
 Write a single program to find the value of the following operations:
10&50, 30||40, ~50, 60>>3, 70<<8, 55>>>2.

 */
public class problem4 {
    public static void main(String[] args) {
        System.out.println("10&50 : "+ (10&50));
        System.out.println("30||40 : "+ (30>0||40>0));
        System.out.println("~50 : "+(~50));
        System.out.println("60>>3 :" +(60>>3));
        System.out.println("70<<8 : "+(70<<8));
        System.out.println("55>>>2 : "+(55>>>2));

    }
}
